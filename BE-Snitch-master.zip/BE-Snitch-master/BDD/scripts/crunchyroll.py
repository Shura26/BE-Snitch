#ajoute un nouveau tableau de pseudos dans la table concernée (chaque table a pour nom l'id de l'anime)
def update_pseudos(table, users):
    pass

def get_ids_already_checked():
    pass

def get_usernames_already_checked():
    pass


#Contient les infomations de nommage dans la base de donnée
class Crunchyroll:
    user_table="crunchyroll_pseudos"
    user_column="pseudo"
    id_table="crunchyroll_ids_checked"
    id_column="anime_id"

