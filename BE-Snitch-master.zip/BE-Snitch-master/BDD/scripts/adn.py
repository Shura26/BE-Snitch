#récupère le starting_id nécessaire a la récupération des pseudos d'adn
def get_starting_id():
    pass

#mets à jour le starting_id nécessaire a la récupération des pseudos d'adn
def update_adn_starting_id(starting_id):
    pass
